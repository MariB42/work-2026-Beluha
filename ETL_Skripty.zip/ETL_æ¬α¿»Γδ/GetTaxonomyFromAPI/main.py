#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Скрипт для обработки орнитологических данных из XLS файла
Читает листы Б1..Б11, столбцы B (отряд), C (семейство), D (род)
Добавляет русскоязычные названия справа от соответствующих столбцов
Использует международные таксономические API (ITIS и GBIF)
"""

import pandas as pd
import requests
import time
import logging
from typing import Dict, Optional, Tuple, List
import argparse
import sys
import re
from xml.etree import ElementTree as ET
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('taxonomy_enrichment.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class OrnithologyDataProcessor:
    """Класс для обработки орнитологических данных из XLS файла"""

    def __init__(self, delay: float = 0.5, use_api: str = 'gbif'):
        """
        Инициализация процессора

        Args:
            delay: задержка между запросами к API (сек)
            use_api: 'itis', 'gbif' или 'both'
        """
        self.delay = delay
        self.use_api = use_api
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'OrnithologyEnricher/1.0',
            'Accept': 'application/json'
        })

        # Базовые URL для API
        self.itis_base_url = "https://www.itis.gov/ITISWebService/services/ITISService"
        self.gbif_base_url = "https://api.gbif.org/v1"

        # Кэш для хранения уже полученных переводов
        self.translation_cache = {}

        # Словари с русскими названиями для быстрого поиска
        self.russian_names = {
            # Отряды птиц
            'orders': {
                'Passeriformes': 'Воробьинообразные',
                'Falconiformes': 'Соколообразные',
                'Strigiformes': 'Совообразные',
                'Anseriformes': 'Гусеобразные',
                'Galliformes': 'Курообразные',
                'Gruiformes': 'Журавлеобразные',
                'Charadriiformes': 'Ржанкообразные',
                'Columbiformes': 'Голубеобразные',
                'Cuculiformes': 'Кукушкообразные',
                'Piciformes': 'Дятлообразные',
                'Coraciiformes': 'Ракшеобразные',
                'Psittaciformes': 'Попугаеобразные',
                'Apodiformes': 'Стрижеобразные',
                'Caprimulgiformes': 'Козодоеобразные',
                'Pelecaniformes': 'Пеликанообразные',
                'Ciconiiformes': 'Аистообразные',
                'Phoenicopteriformes': 'Фламингообразные',
                'Podicipediformes': 'Поганкообразные',
                'Procellariiformes': 'Буревестникообразные',
                'Sphenisciformes': 'Пингвинообразные',
                'Gaviiformes': 'Гагарообразные',
                'Accipitriformes': 'Ястребообразные',
                'Bucerotiformes': 'Птицы-носороги',
                'Coliiformes': 'Птицы-мыши',
                'Eurypygiformes': 'Солнечные цапли',
                'Leptosomiformes': 'Кукушковые',
                'Mesitornithiformes': 'Мезиты',
                'Musophagiformes': 'Туракообразные',
                'Opisthocomiformes': 'Гоацинообразные',
                'Otidiformes': 'Дрофообразные',
                'Pterocliformes': 'Рябкообразные',
                'Suliformes': 'Олушеобразные',
                'Tinamiformes': 'Тинамуобразные',
                'Trogoniformes': 'Трогонообразные'
            },
            # Семейства птиц
            'families': {
                'Passeridae': 'Воробьиные',
                'Corvidae': 'Врановые',
                'Turdidae': 'Дроздовые',
                'Paridae': 'Синицевые',
                'Sturnidae': 'Скворцовые',
                'Columbidae': 'Голубиные',
                'Picidae': 'Дятловые',
                'Alaudidae': 'Жаворонковые',
                'Hirundinidae': 'Ласточковые',
                'Motacillidae': 'Трясогузковые',
                'Fringillidae': 'Вьюрковые',
                'Emberizidae': 'Овсянковые',
                'Sylviidae': 'Славковые',
                'Muscicapidae': 'Мухоловковые',
                'Certhiidae': 'Пищуховые',
                'Sittidae': 'Поползневые',
                'Troglodytidae': 'Крапивниковые',
                'Regulidae': 'Корольковые',
                'Laniidae': 'Сорокопутовые',
                'Oriolidae': 'Иволговые',
                'Bombycillidae': 'Свиристелевые',
                'Prunellidae': 'Завирушковые',
                'Turdidae': 'Дроздовые',
                'Timaliidae': 'Тимелиевые',
                'Zosteropidae': 'Белоглазковые'
            },
            # Роды птиц
            'genera': {
                'Passer': 'Воробей',
                'Corvus': 'Ворон',
                'Turdus': 'Дрозд',
                'Parus': 'Синица',
                'Sturnus': 'Скворец',
                'Columba': 'Голубь',
                'Pica': 'Сорока',
                'Delichon': 'Ласточка',
                'Hirundo': 'Ласточка',
                'Apus': 'Стриж',
                'Carduelis': 'Щегол',
                'Fringilla': 'Зяблик',
                'Emberiza': 'Овсянка',
                'Sylvia': 'Славка',
                'Phylloscopus': 'Пеночка',
                'Muscicapa': 'Мухоловка',
                'Phoenicurus': 'Горихвостка',
                'Erithacus': 'Зарянка',
                'Luscinia': 'Соловей',
                'Tichodroma': 'Стенолаз',
                'Certhia': 'Пищуха',
                'Sitta': 'Поползень',
                'Troglodytes': 'Крапивник',
                'Regulus': 'Королек',
                'Lanius': 'Сорокопут',
                'Oriolus': 'Иволга',
                'Bombycilla': 'Свиристель',
                'Prunella': 'Завирушка',
                'Aegithalos': 'Длиннохвостая синица'
            }
        }

    def _make_request(self, url: str, params: Dict = None, max_retries: int = 3) -> Optional[Dict]:
        """Выполнение HTTP запроса с повторными попытками"""
        for attempt in range(max_retries):
            try:
                response = self.session.get(url, params=params, timeout=10)
                response.raise_for_status()

                content_type = response.headers.get('Content-Type', '').lower()
                if 'xml' in content_type:
                    return response.text
                else:
                    return response.json()

            except requests.exceptions.RequestException as e:
                logger.warning(f"Попытка {attempt + 1}/{max_retries} не удалась: {e}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
                else:
                    logger.error(f"Не удалось выполнить запрос после {max_retries} попыток")
                    return None

    def get_russian_name_from_cache(self, scientific_name: str, taxon_type: str = 'species') -> Optional[str]:
        """
        Получение русского названия из кэша или локальных словарей

        Args:
            scientific_name: научное название
            taxon_type: 'order', 'family', 'genus' или 'species'

        Returns:
            Русское название или None
        """
        # Проверяем кэш
        if scientific_name in self.translation_cache:
            return self.translation_cache[scientific_name]

        # Проверяем локальные словари
        if taxon_type == 'order':
            result = self.russian_names['orders'].get(scientific_name)
        elif taxon_type == 'family':
            result = self.russian_names['families'].get(scientific_name)
        elif taxon_type == 'genus':
            result = self.russian_names['genera'].get(scientific_name)
        else:
            result = None

        # Сохраняем в кэш
        if result:
            self.translation_cache[scientific_name] = result

        return result

    def get_russian_name_from_api(self, scientific_name: str) -> Optional[str]:
        """
        Получение русского названия из API

        Args:
            scientific_name: научное название

        Returns:
            Русское название или None
        """
        try:
            if self.use_api in ['gbif', 'both']:
                # Поиск в GBIF
                url = f"{self.gbif_base_url}/species/match"
                params = {'name': scientific_name, 'verbose': True}

                response = self.session.get(url, params=params, timeout=10)
                if response.status_code == 200:
                    data = response.json()
                    if data.get('matchType') in ['EXACT', 'FUZZY']:
                        taxon_key = data.get('usageKey')
                        if taxon_key:
                            # Получаем народные названия
                            url = f"{self.gbif_base_url}/species/{taxon_key}/vernacularNames"
                            params = {'limit': 100}
                            response = self.session.get(url, params=params, timeout=10)
                            if response.status_code == 200:
                                data = response.json()
                                for result in data.get('results', []):
                                    language = result.get('language', '')
                                    if 'rus' in language.lower() or 'рус' in language.lower():
                                        return result.get('vernacularName')

            if self.use_api in ['itis', 'both']:
                # Поиск в ITIS
                url = f"{self.itis_base_url}/searchByScientificName"
                params = {'srchKey': scientific_name}

                response = self.session.get(url, params=params, timeout=10)
                if response.status_code == 200:
                    root = ET.fromstring(response.text)
                    tsn_elem = root.find('.//tsn')
                    if tsn_elem is not None:
                        tsn = tsn_elem.text
                        # Получаем народные названия
                        url = f"{self.itis_base_url}/getCommonNamesFromTSN"
                        params = {'tsn': tsn}
                        response = self.session.get(url, params=params, timeout=10)
                        if response.status_code == 200:
                            root = ET.fromstring(response.text)
                            for elem in root.findall('.//commonName'):
                                lang = elem.find('language')
                                name = elem.find('commonName')
                                if lang is not None and name is not None:
                                    if 'Russian' in lang.text or 'рус' in lang.text.lower():
                                        return name.text

            return None

        except Exception as e:
            logger.debug(f"Ошибка при получении русского названия из API: {e}")
            return None

    def translate_taxon(self, scientific_name: str, taxon_type: str = 'species') -> str:
        """
        Перевод таксономического названия на русский язык

        Args:
            scientific_name: научное название
            taxon_type: тип таксона ('order', 'family', 'genus', 'species')

        Returns:
            Русское название или исходное название, если перевод не найден
        """
        if not scientific_name or scientific_name.strip() == '' or scientific_name.lower() == 'nan':
            return ''

        # Очищаем название
        scientific_name = scientific_name.strip()

        # Проверяем кэш и локальные словари
        russian_name = self.get_russian_name_from_cache(scientific_name, taxon_type)

        if not russian_name:
            # Пробуем получить из API
            russian_name = self.get_russian_name_from_api(scientific_name)

        if not russian_name:
            # Если перевод не найден, оставляем исходное название
            russian_name = scientific_name
            logger.debug(f"Перевод не найден для {scientific_name}, оставляем исходное")
        else:
            # Сохраняем в кэш
            self.translation_cache[scientific_name] = russian_name
            logger.info(f"Найден перевод: {scientific_name} -> {russian_name}")

        return russian_name

    def process_sheet(self, df: pd.DataFrame, sheet_name: str) -> pd.DataFrame:
        """
        Обработка одного листа с данными

        Args:
            df: DataFrame с данными листа
            sheet_name: имя листа

        Returns:
            DataFrame с добавленными столбцами для русских названий
        """
        logger.info(f"Обработка листа {sheet_name}, строк: {len(df)}")

        # Определяем индексы столбцов B, C, D (0-based)
        # B - колонка 1, C - колонка 2, D - колонка 3
        col_b_idx = 1  # Отряд
        col_c_idx = 2  # Семейство
        col_d_idx = 3  # Род

        # Проверяем, что столбцы существуют
        if len(df.columns) < 4:
            logger.warning(f"В листе {sheet_name} недостаточно столбцов (нужно минимум 4)")
            return df

        # Создаем новые столбцы для русских названий
        # Вставляем справа от соответствующих столбцов
        # Новые столбцы будут на позициях: 2 (после B), 4 (после C), 6 (после D)

        # Получаем имена столбцов
        col_b_name = df.columns[col_b_idx]
        col_c_name = df.columns[col_c_idx]
        col_d_name = df.columns[col_d_idx]

        # Создаем имена для новых столбцов
        col_b_ru_name = f"{col_b_name}_RU"
        col_c_ru_name = f"{col_c_name}_RU"
        col_d_ru_name = f"{col_d_name}_RU"

        # Вставляем новые столбцы справа от существующих
        # Разбиваем DataFrame на части и вставляем новые столбцы

        # Создаем список всех столбцов с новыми позициями
        new_columns = []
        for i, col in enumerate(df.columns):
            new_columns.append(col)
            if i == col_b_idx:
                new_columns.append(col_b_ru_name)
            elif i == col_c_idx:
                new_columns.append(col_c_ru_name)
            elif i == col_d_idx:
                new_columns.append(col_d_ru_name)

        # Создаем новый DataFrame с пустыми столбцами
        for new_col in [col_b_ru_name, col_c_ru_name, col_d_ru_name]:
            if new_col not in df.columns:
                df[new_col] = ''

        # Переупорядочиваем столбцы
        df = df[new_columns]

        # Обрабатываем строки
        empty_counter = 0  # Счетчик пустых строк подряд
        processed_rows = 0

        for idx, row in df.iterrows():
            # Получаем значения из столбцов B, C, D
            value_b = str(row.iloc[col_b_idx]).strip() if pd.notna(row.iloc[col_b_idx]) else ''
            value_c = str(row.iloc[col_c_idx]).strip() if pd.notna(row.iloc[col_c_idx]) else ''
            value_d = str(row.iloc[col_d_idx]).strip() if pd.notna(row.iloc[col_d_idx]) else ''

            # Проверяем на пустые ячейки
            is_empty_b = value_b == '' or value_b.lower() == 'nan'
            is_empty_c = value_c == '' or value_c.lower() == 'nan'
            is_empty_d = value_d == '' or value_d.lower() == 'nan'

            # Если все три ячейки пустые, увеличиваем счетчик
            if is_empty_b and is_empty_c and is_empty_d:
                empty_counter += 1
                logger.debug(f"Строка {idx}: все три ячейки пустые (счетчик: {empty_counter})")

                # Если три пустые строки подряд - останавливаем обработку листа
                if empty_counter >= 3:
                    logger.info(f"Достигнут конец данных на листе {sheet_name} (3 пустые строки подряд)")
                    break
                continue
            else:
                # Сбрасываем счетчик пустых строк
                empty_counter = 0

            # Пропускаем строки, где нет данных в нужных столбцах
            if is_empty_b and is_empty_c and is_empty_d:
                continue

            processed_rows += 1
            logger.info(f"Обработка строки {idx + 1} на листе {sheet_name}")

            # Получаем русские названия
            # 1. Отряд (столбец B)
            if not is_empty_b:
                russian_order = self.translate_taxon(value_b, 'order')
                df.at[idx, col_b_ru_name] = russian_order
                logger.info(f"  Отряд: {value_b} -> {russian_order}")

            # 2. Семейство (столбец C)
            if not is_empty_c:
                russian_family = self.translate_taxon(value_c, 'family')
                df.at[idx, col_c_ru_name] = russian_family
                logger.info(f"  Семейство: {value_c} -> {russian_family}")

            # 3. Род (столбец D)
            if not is_empty_d:
                russian_genus = self.translate_taxon(value_d, 'genus')
                df.at[idx, col_d_ru_name] = russian_genus
                logger.info(f"  Род: {value_d} -> {russian_genus}")

            # Задержка между запросами к API
            time.sleep(self.delay)

        logger.info(f"Лист {sheet_name} обработан. Обработано строк: {processed_rows}")
        return df

    def process_file(self, input_file: str, output_file: str = None):
        """
        Обработка XLS файла с листами Б1..Б11

        Args:
            input_file: путь к входному файлу
            output_file: путь к выходному файлу (опционально)
        """
        logger.info(f"Начинаем обработку файла: {input_file}")

        try:
            # Загружаем файл
            wb = pd.ExcelFile(input_file, engine='openpyxl')
            sheet_names = wb.sheet_names

            # Фильтруем листы, начинающиеся с "Б"
            target_sheets = [name for name in sheet_names if name.startswith('Б')]

            if not target_sheets:
                logger.error(f"Не найдено листов, начинающихся с 'Б'. Доступные листы: {sheet_names}")
                return

            logger.info(f"Найдены листы для обработки: {target_sheets}")

            # Обрабатываем каждый лист
            with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
                for sheet_name in target_sheets:
                    try:
                        logger.info(f"\n{'=' * 50}")
                        logger.info(f"Обработка листа: {sheet_name}")
                        logger.info(f"{'=' * 50}")

                        # Читаем лист
                        df = pd.read_excel(input_file, sheet_name=sheet_name, header=None, engine='openpyxl')

                        # Обрабатываем лист
                        df_processed = self.process_sheet(df, sheet_name)

                        # Сохраняем обработанный лист
                        df_processed.to_excel(writer, sheet_name=sheet_name, index=False, header=False)

                        logger.info(f"Лист {sheet_name} успешно обработан и сохранен")

                    except Exception as e:
                        logger.error(f"Ошибка при обработке листа {sheet_name}: {e}")
                        # Сохраняем оригинальный лист в случае ошибки
                        df = pd.read_excel(input_file, sheet_name=sheet_name, header=None, engine='openpyxl')
                        df.to_excel(writer, sheet_name=sheet_name, index=False, header=False)
                        continue

            logger.info(f"\n{'=' * 50}")
            logger.info(f"Обработка завершена! Результат сохранен в: {output_file}")
            logger.info(f"{'=' * 50}")

        except Exception as e:
            logger.error(f"Ошибка при обработке файла: {e}")
            raise


def main():
    """Основная функция"""
    parser = argparse.ArgumentParser(
        description='Обработка орнитологических данных из XLS файла с добавлением русских названий'
    )
    parser.add_argument(
        'input_file',
        help='Путь к входному XLS файлу'
    )
    parser.add_argument(
        '-o', '--output',
        help='Путь к выходному файлу (по умолчанию: input_enriched.xlsx)'
    )
    parser.add_argument(
        '--api',
        choices=['itis', 'gbif', 'both'],
        default='gbif',
        help='Выбор API: itis, gbif или both (по умолчанию: gbif)'
    )
    parser.add_argument(
        '--delay',
        type=float,
        default=0.5,
        help='Задержка между запросами в секундах (по умолчанию: 0.5)'
    )

    args = parser.parse_args()

    # Определяем выходной файл
    if args.output is None:
        if args.input_file.endswith('.xls'):
            args.output = args.input_file.replace('.xls', '_enriched.xlsx')
        elif args.input_file.endswith('.xlsx'):
            args.output = args.input_file.replace('.xlsx', '_enriched.xlsx')
        else:
            args.output = args.input_file + '_enriched.xlsx'

    # Создаем процессор и обрабатываем файл
    processor = OrnithologyDataProcessor(delay=args.delay, use_api=args.api)
    processor.process_file(args.input_file, args.output)


if __name__ == "__main__":
    main()