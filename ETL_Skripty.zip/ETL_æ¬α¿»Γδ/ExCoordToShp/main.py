# main.py
"""
Главный скрипт для обработки Excel файлов.
Использует функции из модулей coordinate_converter и excel_filters.
"""

import os
import sys
from pathlib import Path

# Добавляем текущую директорию в путь поиска модулей
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Импортируем наши модули
from coordinate_converter import convert_coordinate
from excel_filters import filter_excel_by_keywords, process_coordinates_in_excel, print_stats
from shp_creator import create_shp_from_excel, print_shp_stats


def main():
    """
    Основная функция для обработки файлов в 3 этапа:
    Основная цель: создать shp файл для последующей загрузки в базу данных или Панораму, содержащий точки наблюдения,
    и включающий все заданные в исходном файле аттрибуты (название и описание биотопа, название точки наблюдения)
    1. Этап- удаление лишних записей о птицах на всех листах (т.е. оставляем только строчки с координатами)
        Фильтрация по ключевым словам
    2. Этап - преобразование всех координат в единый формат (градусы и десятичные доли градусов)
    3. Этап - создание Shapefile с точками наблюдения
    Скрипт выполняется поэтапно, после каждого этапа нужно проверить и откорректировать получившийся файл.
    Перед каждым этапом нужно сделать копию исходного файла.

    Расскомментировать нужный этап.
    """

    print("\n" + "=" * 70)
    print(" ОБРАБОТКА ДАННЫХ НАБЛЮДЕНИЙ (3 ЭТАПА)")
    print("=" * 70)

    # Пути к файлам
    data_file = "Data_step2.xlsx"
    output_shp = "observation_points.shp"

    # Проверяем, существует ли файл
    if not Path(data_file).exists():
        print(f"\n❌ Ошибка: Файл '{data_file}' не найден!")
        print("   Убедитесь, что файл находится в текущей директории.")
        return

    # # ============================================================
    # # ЭТАП 1: Фильтрация по ключевым словам
    # # ============================================================
    # print("\n" + "🟢 ЭТАП 1: Фильтрация по ключевым словам")
    # print("-" * 70)
    #
    # try:
    #     keywords = ["биотоп", "секунда", "точка"]
    #     sheets = [f"Б{i}" for i in range(1, 12)]  # Б1 - Б11
    #
    #     filter_stats = filter_excel_by_keywords(
    #         file_path=data_file,
    #         keywords=keywords,
    #         sheet_names=sheets,
    #         whole_word=True  # искать целые слова
    #     )
    #
    #     print_stats(filter_stats, "Статистика фильтрации")
    # except Exception as e:
    #     print(f"❌ Ошибка на этапе 1: {e}")
    #     return

    # # ============================================================
    # # ЭТАП 2: Обработка координат
    # # ============================================================
    # print("\n" + "🔵 ЭТАП 2: Преобразование координат")
    # print("-" * 70)
    #
    # try:
    #     coord_stats = process_coordinates_in_excel(
    #         file_path=data_file,
    #         lon_col='G',  # столбец с долготой
    #         lat_col='H',  # столбец с широтой
    #         output_lon_col='I',  # куда записать результат для долготы
    #         output_lat_col='J'  # куда записать результат для широты
    #     )
    #
    #     print(f"✅ Обработано координат: {coord_stats['processed']}")
    #     print(f"⚠️  Ошибок преобразования: {coord_stats['errors']}")
    #     print(f"📊 Всего строк: {coord_stats['total_rows']}")
    # except Exception as e:
    #     print(f"❌ Ошибка на этапе 2: {e}")
    #     return

    # ============================================================
    # ЭТАП 3: Создание Shapefile
    # ============================================================
    print("\n" + "🟠 ЭТАП 3: Создание Shapefile")
    print("-" * 70)

    try:
        # Создаем SHP файл с точками наблюдения
        # Используем столбцы:
        # A - название биотопа (biotope_name)
        # B - номер биотопа (biotope_number)
        # C - описание биотопа (biotope_description)
        # D - номер точки наблюдения (obspoint_number)
        # E - название точки наблюдения (obspoint_name)
        # F - долгота (lon)
        # G - широта (lat)

        shp_path, shp_stats = create_shp_from_excel(
            excel_path=data_file,
            output_shp_path=output_shp,
            sheet_name=None,  # используем активный лист
            id_col=None,  # ID будет создан автоматически
            biotope_name_col='A',
            biotope_number_col='B',
            biotope_description_col='C',
            obspoint_number_col='D',
            obspoint_name_col='E',
            lon_col='F',  # или 'I' если используем преобразованные
            lat_col='G',  # или 'J' если используем преобразованные
            crs='EPSG:4326'  # WGS84
        )

        print_shp_stats(shp_stats)

    except Exception as e:
        print(f"❌ Ошибка на этапе 3: {e}")
        import traceback
        traceback.print_exc()
        return

    # ============================================================
    # ИТОГОВЫЙ ОТЧЕТ
    # ============================================================
    print("\n" + "=" * 70)
    print(" ✅ ОБРАБОТКА УСПЕШНО ЗАВЕРШЕНА!")
    print("=" * 70)

    print("\n📋 Итоговые результаты:")
    print(f"  📁 Исходный файл: {data_file}")
    print(f"  📁 Выходной SHP:  {shp_path}")
    print(f"  📊 Количество точек: {shp_stats.get('valid_points', 0)}")
    print(f"  🗺️  Система координат: WGS84 (EPSG:4326)")

    print("\n📌 Поля в SHP файле:")
    fields = shp_stats.get('fields', [])
    for field in fields:
        print(f"  • {field}")

    print("\n💡 SHP файл можно открыть в QGIS, ArcGIS или других ГИС-приложениях.")


if __name__ == "__main__":
    main()

