# excel_filters.py
"""
Модуль для работы с Excel файлами.
Содержит функции для фильтрации и обработки данных.
"""

import re
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter
import pandas as pd


def filter_excel_by_keywords(file_path, keywords, sheet_names, whole_word=True):
    """
    Фильтрует строки в указанных листах Excel файла,
    оставляя только те, которые содержат хотя бы одно из ключевых слов.

    Args:
        file_path (str): путь к Excel файлу
        keywords (list): список ключевых слов для поиска
        sheet_names (list): список имен листов для обработки
        whole_word (bool): искать целые слова или вхождения

    Returns:
        dict: статистика по каждому листу
    """
    # Загружаем workbook
    wb = load_workbook(file_path)

    # Создаем паттерн для поиска
    if whole_word:
        pattern = re.compile(r'\b(' + '|'.join(re.escape(kw) for kw in keywords) + r')\b', re.IGNORECASE)
    else:
        pattern = re.compile('|'.join(re.escape(kw) for kw in keywords), re.IGNORECASE)

    stats = {}

    # Обрабатываем каждый указанный лист
    for sheet_name in sheet_names:
        if sheet_name not in wb.sheetnames:
            print(f"Лист '{sheet_name}' не найден. Пропускаем.")
            stats[sheet_name] = {'found': False, 'rows_before': 0, 'rows_after': 0}
            continue

        ws = wb[sheet_name]

        # Собираем данные в список строк
        data = []
        total_rows = ws.max_row

        for row in ws.iter_rows(values_only=True):
            # Проверяем, содержит ли строка хотя бы одно из ключевых слов
            row_str = ' '.join([str(cell) if cell is not None else '' for cell in row])
            if pattern.search(row_str):
                data.append(row)

        # Очищаем лист
        ws.delete_rows(1, ws.max_row)

        # Записываем отфильтрованные данные обратно
        for row_idx, row_data in enumerate(data, start=1):
            for col_idx, cell_value in enumerate(row_data, start=1):
                ws.cell(row=row_idx, column=col_idx, value=cell_value)

        stats[sheet_name] = {
            'found': True,
            'rows_before': total_rows,
            'rows_after': len(data),
            'deleted': total_rows - len(data)
        }

    # Сохраняем изменения
    wb.save(file_path)

    return stats


def process_coordinates_in_excel(file_path, lon_col='G', lat_col='H', output_lon_col='I', output_lat_col='J'):
    """
    Обрабатывает координаты в Excel файле.

    Args:
        file_path (str): путь к Excel файлу
        lon_col (str): буква столбца с долготой
        lat_col (str): буква столбца с широтой
        output_lon_col (str): буква столбца для результата долготы
        output_lat_col (str): буква столбца для результата широты

    Returns:
        dict: статистика обработки
    """
    # Здесь импортируем функцию из coordinate_converter
    from coordinate_converter import convert_coordinate

    # Загружаем workbook
    wb = load_workbook(file_path)
    ws = wb.active

    # Получаем номера столбцов
    lon_col_num = ws[lon_col + '1'].column
    lat_col_num = ws[lat_col + '1'].column
    output_lon_col_num = ws[output_lon_col + '1'].column
    output_lat_col_num = ws[output_lat_col + '1'].column

    # Добавляем заголовки если их нет
    if ws.cell(row=1, column=output_lon_col_num).value is None:
        ws.cell(row=1, column=output_lon_col_num).value = "Долгота (десятичные градусы)"
    if ws.cell(row=1, column=output_lat_col_num).value is None:
        ws.cell(row=1, column=output_lat_col_num).value = "Широта (десятичные градусы)"

    # Проходим по строкам
    processed_count = 0
    errors = 0

    for row_num in range(2, ws.max_row + 1):
        # Получаем значения
        lon_value = ws.cell(row=row_num, column=lon_col_num).value
        lat_value = ws.cell(row=row_num, column=lat_col_num).value

        # Обработка долготы
        lon_result = convert_coordinate(lon_value)
        if lon_result is not None:
            ws.cell(row=row_num, column=output_lon_col_num).value = lon_result
            processed_count += 1
        else:
            ws.cell(row=row_num, column=output_lon_col_num).value = lon_value
            if lon_value is not None and str(lon_value).strip():
                errors += 1

        # Обработка широты
        lat_result = convert_coordinate(lat_value)
        if lat_result is not None:
            ws.cell(row=row_num, column=output_lat_col_num).value = lat_result
            processed_count += 1
        else:
            ws.cell(row=row_num, column=output_lat_col_num).value = lat_value
            if lat_value is not None and str(lat_value).strip():
                errors += 1

    # Сохраняем файл
    wb.save(file_path)

    return {
        'processed': processed_count,
        'errors': errors,
        'total_rows': ws.max_row - 1  # минус заголовок
    }


def print_stats(stats, title="Статистика обработки"):
    """
    Выводит статистику обработки в красивом формате.
    """
    print("\n" + "=" * 60)
    print(f" {title}")
    print("=" * 60)

    for key, value in stats.items():
        print(f"\n{key}:")
        for k, v in value.items():
            print(f"  {k}: {v}")